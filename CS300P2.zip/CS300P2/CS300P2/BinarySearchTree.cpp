/*
===========================
*  NAME: John Brungard
*  COURSE: CS300
*  PROJECT 2: Binary Tree
*  DATE: 10/08/2022
===========================
*/

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>

using namespace std;

/*
=====================================
* Global Structures and Constructors
=====================================
*/


// Defines a Course structure
struct Course {
    string number;  // Identifier
    string name;
    vector <string> prereq;
};

// Defines tree nodes
struct Node {
    Course course;
    Node* left;
    Node* right;

    // Default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // Initializes with a course
    Node(Course aCourse) :
        Node() {
        course = aCourse;
    }
};

/*
*==========================================
* Binary Tree Class Attributes & Methods
*==========================================
*/

class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Course course);
    void inOrder(Node* node);

public:
    BinarySearchTree();
    void InOrder();
    void Insert(Course course);
    Course Search(string courseNum);
    Course printMatch(string courseNum);
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    root = nullptr;
}

/**
 * Begins traversing the tree alphabetically with the root
 */
void BinarySearchTree::InOrder() {
    inOrder(root);
}

/*
*  Prints the contents of the tree alphabetically
*/
void BinarySearchTree::inOrder(Node* node) {
    // If the node holds a course then
    if (node != nullptr) {
        //InOrder left
        inOrder(node->left);

        // Output the general information of the current course
        std::cout << node->course.number << ", " << node->course.name << endl;

        //InOrder right
        inOrder(node->right);
    }
}

/**
 * Insert a course
 */
void BinarySearchTree::Insert(Course course) {
    // If the tree is empty then
    if (root == nullptr) {
        // The course is assigned to the root node
        root = new Node(course);
        root->left = nullptr;
        root->right = nullptr;
    }
    // If the tree is NOT empty then
    else {
        // Find a hierarchal node to insert the course
        addNode(root, course);
    }
}

/**
 * Find a position to insert the course into the tree using recursion
 */
void BinarySearchTree::addNode(Node* node, Course course) {
    // The current node's identifier that helps correctly place new courses
    string currNode = node->course.number;
    // The course that is attempting to be added into the tree
    string newCourse = course.number;

    // If the node's ID is greater than the new course's ID then
    if (currNode > newCourse) {
        // If currNode has no left child then
        if (node->left == nullptr) {
            // A new node becomes currNode's left child holding the new course
            node->left = new Node(course);
        }
        // If currNode has a left child then 
        else {
            // Recurse down the left child
            addNode(node->left, course);
        }
    }
    // If the node's ID is less than the new course's ID then
    else {
        // If currNode has no right child then
        if (node->right == nullptr) {
            // A new node becomes currNode's right child holding the new course
            node->right = new Node(course);
        }
        // If currNode has a right child then 
        else {
            // Recurse down the right child
            addNode(node->right, course);
        }
    }
}

/**
 * Searches for the user-specified course number
 */
Course BinarySearchTree::Search(string courseNum) {
    // Set current node equal to root for traversal
    Node* currentNode = root;

    // Traverses the tree until a match or a node possesses no child
    while (currentNode != nullptr) {
        // If a match is found, return the matching node's course information
        if (currentNode->course.number == courseNum) {
            return currentNode->course;
        }
        // The tree traverses left because courseNum is smaller
        else if (currentNode->course.number > courseNum) {
            currentNode = currentNode->left;
        }
        // The tree traverses right because courseNum is larger
        else {
            currentNode = currentNode->right;
        }
    }
    // The user-specified course number was not found in the tree
    // Return an empty course
    Course course;
    return course;
}

/*
*  Prints the matching course information or a "no match" message
*/
Course BinarySearchTree::printMatch(string courseNum) {
    // course is assigned the search results for the user-specified course number
    Course course = Search(courseNum);

    // If the user-specified course number was NOT found in the tree
    if (course.number.empty()) {
        // Print a "no match" message
        std::cout << courseNum << " is not within the available courses." << endl;
    }
    // If the user-specified course number was found in the tree
    else {
        // Output the general information of the current course
        std::cout << course.number << ", " << course.name;

        // Calculate the total number of prerequisites for the course
        int length = course.prereq.size();

        // If there is at least one prerequisite for the course then
        if (length > 0) {
            std::cout << "\nPrerequisites: ";
            // Traverse through all the courses prerequisites to print
            for (int i = 0; i < length; ++i) {
                // If another prerequisite needs printed then
                if (i != (length - 1)) {
                    // Print the prerequisite followed by a comma
                    std::cout << course.prereq.at(i) << ", ";
                }
                // If the last prerequisite for the course then
                else {
                    // Print just the prerequisite
                    std::cout << course.prereq.at(i);
                }
            }
        }
        std::cout << endl;
    }
    return course;
}

/*
*==================================
*  Load Function
*==================================
*/

/*
* Load a CSV file containing courses into a vector
*/
void loadTree(BinarySearchTree* bst) {
    ifstream inFS;
    string line;
    string token;
    Course course;
    vector <string> tempVector;

    // Attempt to open the input file
    inFS.open("ABCU.txt");
    if (!inFS.is_open()) {
        std::cout << "File could not be opened." << endl;

        return;
    }

    // Checks for any raised errors and retrieves each line from the file 
    while (inFS.good() && getline(inFS, line) ) {
        // Empties the vector for the next iteration
        tempVector.clear();

        // If the line is empty then
        if (line.length() == 0) {
            // Send an error message
            std::cout << "No data in line" << endl;
        }
        // If the line is NOT empty then
        else {
            // Determine if the line is formatted correctly through commas
            int commaCount = count(line.begin(), line.end(), ',');

            switch (commaCount) {

            // If the line is NOT formatted correctly then
            case 0:
                // Send an error message
                std::cout << "Invalid line" << endl;

                break;

            // If the file is formatted correctly then
            default:
                // Empties the vector for the next iteration
                course.prereq.clear();
                // Declare a stringstream for obtaining tokens of a line
                stringstream str(line);

                // Split the contents of the line by each comma
                while (getline(str, token, ',')) {
                    // Add all tokens in the line into the vector
                    tempVector.push_back(token);
                }

                // Assign the first token to be the course number
                course.number = tempVector.at(0);
                // Assign the second token to be course name
                course.name = tempVector.at(1);

                // Check tempVector for any additional tokens for prerequisites
                for (unsigned int prereqCount = 2; prereqCount < tempVector.size(); ++prereqCount) {
                    // Add the token to the prereq vector for the respective line
                    course.prereq.push_back(tempVector.at(prereqCount));
                }
                // Insert the tokens formatted for the course into the binary tree
                bst->Insert(course);
            }
        }


    }
    inFS.close();
    std::cout << "Data structure loaded" << endl << endl;
}

/*
*========
*  MAIN
*========
*/

int main(int argc, char* argv[]) {

    // Define a binary search tree to hold all courses
    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    Course course;
    // Used to search for a course
    string input;

    // Display the menu and choices
    int choice = 0;
    std::cout << "Welcome to the course planner" << endl << endl;
    while (choice != 9) {
        std::cout << "  1. Load Data Structure" << endl;
        std::cout << "  2. Print Course List" << endl;
        std::cout << "  3. Print Course" << endl;
        std::cout << "  9. Exit" << endl << endl;
        std::cout << "What would you like to do? ";
        cin >> choice;

        switch (choice) {

        case 1:

            loadTree(bst);

            break;

        case 2:
            std::cout << "Here is a sample schedule:" << endl << endl;

            bst->InOrder();
            std::cout << endl;

            break;

        case 3:
            std::cout << "What course do you want to know about? ";

            cin >> input;
            
            // Capitalizes the entire course number for comparisons
            for (auto& c : input) c = toupper(c);

            course = bst->printMatch(input);
            std::cout << endl;

            break;

        case 9:
            std::cout << "Thank you for using the course planner!" << endl;

            exit(0);

        default:
            std::cout << choice << " is not a valid option." << endl << endl;

            break;
        }
    }

    return 0;
}